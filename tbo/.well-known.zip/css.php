   <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <!-- MDB icon -->
  <link rel="icon" href="img/mdb-favicon.ico" type="image/x-icon">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css">
  <!-- Google Fonts Roboto -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap">
  <!-- Bootstrap core CSS -->
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <!-- Material Design Bootstrap -->
  <link rel="stylesheet" href="css/mdb.min.css">
  <!-- DataTable -->
  <link rel="stylesheet" href="css/datatables.min.css">
  <!-- Your custom styles (optional) -->
  <link rel="stylesheet" href="css/style.css">
		<link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.2.2/css/buttons.dataTables.min.css">
  <!-- 
   <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
    // Google Fonts 
   <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap">
    // Bootstrap core CSS 
   <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/css/bootstrap.min.css" rel="stylesheet">
    // Material Design Bootstrap 
   <link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.19.1/css/mdb.min.css" rel="stylesheet">
  -->

  <?php $image="css/images/"; ?>
  <?php $documents="docs/"; ?>
  <style type="text/css">
	body{
         background-image: url("css/images/vigilus-bg copie.jpg");
		/* Image is centered vertically and horizontally at all times */
          background-position: center center;
          
          /* Image doesn't repeat */
          background-repeat: no-repeat;
          
          /* Makes the image fixed in the viewport so that it doesn't move when 
             the content height is greater than the image height */
          background-attachment: fixed;
          
          /* This is what makes the background image rescale based on its container's size */
          background-size: cover;
          
          /* Pick a solid background color that will be displayed while the background image is loading */
          
	}
</style>